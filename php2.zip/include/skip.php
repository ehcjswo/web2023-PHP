<div id="skip">
    <a href="#header">헤더 영역 바로가기</a>
    <a href="#main">컨텐츠 영역 바로가기</a>
    <a href="#footer">컨텐츠 영역 바로가기</a>
</div> 