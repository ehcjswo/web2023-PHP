<footer id="footer" >
    <div class="footer__inner  container mb100">
        <div>Copyright @ 2023 getgrovy</div>
        <div>blog by getgrovy</div>
    </div>
</footer>
<!-- footer -->