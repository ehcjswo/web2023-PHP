<!-- css -->
<link rel="stylesheet" href="../html/assets/css/style.css">
<!-- script -->
<script defer src="../html/assets/js/common.js"></script>